package com.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SampleModel {

    @JsonProperty("day")
    private String day;

    @JsonProperty("task")
    private String task;

    @JsonProperty("priority")
    private String priority;

    @JsonProperty("deadline")
    private String deadline;

    @JsonProperty("ID")
    private String ID;

    public SampleModel(String day, String task, String priority, String deadline, String ID) {
        this.day = day;
        this.task = task;
        this.priority = priority;
        this.deadline = deadline;
        this.ID = ID;
    }

    public String getDay() {
        return day;
    }
    public void setDay(String day) {
        this.day = day;
    }

    public String getTask() {
        return task;
    }
    public void setTask(String task) {
        this.task = task;
    }

    public String getPriority() {
        return priority;
    }
    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getDeadline() {
        return deadline;
    }
    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

   
    public String getID() {
        return ID;
    }
    public void setID(String ID) {
        this.ID = ID;
    }
}
