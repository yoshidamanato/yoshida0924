package com.example.service;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.model.SampleModel;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono;

@Component("DELETE")
public class DeleteService implements Function<Mono<SampleModel>, Mono<String>> {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Mono<String> apply(Mono<SampleModel> mono) {
        return mono.map(sample -> {

            String responseMessage = "DELETE RESULT";

            String id = sample.getID();

            if (id != null && !id.isEmpty()) {

                String sql = "DELETE FROM ToDo WHERE id = ? ";

                
                try {
                    int rows = jdbcTemplate.update(sql, id);

                    Map<String, Object> result = new HashMap<>();
                    result.put("削除結果", rows + " 行が削除されました");

                    ObjectMapper objectMapper = new ObjectMapper();
                    responseMessage = objectMapper.writeValueAsString(result);

                } catch (Exception e) {
                    e.printStackTrace();
                    responseMessage = "DBエラー: " + e.getMessage();
                }

            } else {
                responseMessage = "パラメーターが設定されていません";
            }
        
            return responseMessage;

        });
    }
}
